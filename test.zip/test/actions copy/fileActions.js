export const SET_FILE_DATA = 'SET_FILE_DATA';

export const setFileData = (data) => ({
  type: SET_FILE_DATA,
  payload: data,
});
